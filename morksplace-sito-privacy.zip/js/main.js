(function(){
  'use strict';
  var $ = function(s,r){return (r||document).querySelector(s)};
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var clamp = function(v,a,b){return Math.min(b,Math.max(a,v))};

  /* ---------- IMPOSTAZIONI: numero WhatsApp del locale e link del canale ---------- */
  var WA_NUMERO = '3532248598';   /* es. '3471234567' (senza spazi) */
  var WA_CANALE = 'https://whatsapp.com/channel/0029VbDwIwuBadmboTmtaT38';   /* es. 'https://whatsapp.com/channel/XXXXXXXX' */
  var TEL_LOCALE = '+393532248598';
  var ORARIO = '20:30';

  /* ---------- dati online (Supabase): solo lettura pubblica di "aperto" e locandina ---------- */
  var SB='https://ioaifwmurjlgrkpmjaxi.supabase.co', KEY='sb_publishable_JbHpR373pyoLA_UsLkBNmQ_QrOc7KdN';
  var mem={open:false,poster:null};
  function rpc(fn,args){
    return fetch(SB+'/rest/v1/rpc/'+fn,{method:'POST',headers:{'apikey':KEY,'Content-Type':'application/json'},body:JSON.stringify(args)})
      .then(function(r){return r.text().then(function(t){var j=null;try{j=t?JSON.parse(t):null}catch(x){}
        if(!r.ok)throw new Error('Errore di connessione');return j})});
  }
  function loadPublic(){
    return rpc('info_pubblica',{}).then(function(j){if(j){mem.open=j.aperto===true;mem.poster=(j.locandina&&j.locandina.img)?j.locandina:null}renderGuest()}).catch(function(){});
  }

  /* ---------- calendario: mar e gio serate, 2° venerdì evento ---------- */
  var DAYS=['domenica','lunedì','martedì','mercoledì','giovedì','venerdì','sabato'];
  var MONTHS_FULL=['gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre'];
  function iso(d){return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2)}
  function today12(){var n=new Date();return new Date(n.getFullYear(),n.getMonth(),n.getDate(),12)}
  function secondFriday(y,m){var d=new Date(y,m,1,12);return new Date(y,m,1+((5-d.getDay()+7)%7)+7,12)}
  function isEventDay(d){return iso(d)===iso(secondFriday(d.getFullYear(),d.getMonth()))}
  function nextEvent(){var t=today12(),sf=secondFriday(t.getFullYear(),t.getMonth());return sf>=t?sf:secondFriday(t.getFullYear(),t.getMonth()+1)}
  function upcomingNights(n){var out=[],d=today12();for(var i=0;i<60&&out.length<n;i++){if(d.getDay()===2||d.getDay()===4)out.push(new Date(d));d.setDate(d.getDate()+1)}return out}
  function longDate(d){var s=DAYS[d.getDay()]+' '+d.getDate()+' '+MONTHS_FULL[d.getMonth()];return s.charAt(0).toUpperCase()+s.slice(1)}
  function pd(s){var p=s.split('-');return new Date(+p[0],+p[1]-1,+p[2],12)}
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}

  /* ---------- WhatsApp: numero e canale ---------- */
  function waNumber(){var d=String(WA_NUMERO).replace(/\D/g,'');if(!d)return '';if(d.indexOf('00')===0)d=d.slice(2);if(d.length===10&&d.charAt(0)==='3')d='39'+d;return d}
  var hasWa=!!waNumber(), hasChan=/^https?:\/\//.test(WA_CANALE);
  [].forEach.call(document.querySelectorAll('.js-canale,#canale'),function(el){el.hidden=!hasChan});
  if(hasChan){$('#canaleBtn').href=WA_CANALE;[].forEach.call(document.querySelectorAll('.js-canale-link'),function(a){a.href=WA_CANALE})}

  /* ---------- prenotazione via WhatsApp (messaggio già scritto) ---------- */
  var wDate=$('#wDate'), wPeople=$('#wPeople'), wName=$('#wName'), wCard=$('#wCard'), wBtn=$('#wBtn'), wPrev=$('#wPrev');
  function waMessage(){
    var n=parseInt(wPeople.value,10)||1, dd=wDate.value?pd(wDate.value):null;
    var name=wName.value.trim(), card=wCard.value.trim();
    return "Ciao! Vorrei prenotare un tavolo da Mòrk's Place per "+(dd?longDate(dd).toLowerCase():'…')+" alle "+ORARIO+", per "+n+(n===1?' persona':' persone')+".\n"+
      "Nome: "+(name||'…')+"\nTessera ARCI n°: "+(card||'…')+"\nGrazie!";
  }
  var wErr=$('#wErr'), touched=false;
  /* tutti i campi sono obbligatori: senza, il link a WhatsApp non parte */
  function waMissing(){
    var out=[];
    if(!wDate.value)out.push([wDate,'la serata']);
    if(!wPeople.value)out.push([wPeople,'il numero di persone']);
    if(wName.value.trim().split(/\s+/).filter(Boolean).length<2)out.push([wName,'nome e cognome']);
    if(wCard.value.trim().length<3)out.push([wCard,'il numero della tessera ARCI']);
    return out;
  }
  function showErr(miss){
    [wDate,wPeople,wName,wCard].forEach(function(el){var bad=touched&&miss.some(function(x){return x[0]===el});if(bad)el.setAttribute('aria-invalid','true');else el.removeAttribute('aria-invalid')});
    if(touched&&miss.length){wErr.hidden=false;wErr.textContent='Per prenotare compila tutti i campi: manca '+miss.map(function(x){return x[1]}).join(', ')+'.'}
    else wErr.hidden=true;
  }
  function syncWa(){
    var m=waMessage(), miss=waMissing(), ok=!miss.length;
    wPrev.innerHTML='<b>Messaggio che invierai</b><br>'+esc(m).replace(/\n/g,'<br>');
    if(!ok){wBtn.href='#prenota';wBtn.removeAttribute('target');wBtn.setAttribute('aria-disabled','true');wBtn.classList.add('is-off')}
    else{wBtn.removeAttribute('aria-disabled');wBtn.classList.remove('is-off');wBtn.setAttribute('target','_blank')}
    if(hasWa){if(ok)wBtn.href='https://wa.me/'+waNumber()+'?text='+encodeURIComponent(m);$('#wBtnTxt').textContent='Scrivici su WhatsApp'}
    else{if(ok){wBtn.href='tel:'+TEL_LOCALE;wBtn.removeAttribute('target')}$('#wBtnTxt').textContent='Chiama per prenotare'}
    showErr(miss);
  }
  wBtn.addEventListener('click',function(e){
    var miss=waMissing(); if(!miss.length)return;
    e.preventDefault(); touched=true; showErr(miss); miss[0][0].focus();
  });
  [wDate,wPeople,wName,wCard].forEach(function(el){el.addEventListener('input',syncWa);el.addEventListener('change',syncWa)});
  $('#waForm').addEventListener('submit',function(e){e.preventDefault()});

  /* ---------- render ---------- */
  function renderGuest(){
    var lb=$('#liveBadge'), lt=$('#liveText');
    lb.classList.toggle('open',mem.open);
    if(mem.open){lt.textContent='Aperti ora'}
    else{
      var d=today12(),i,ev=false;
      for(i=0;i<60;i++){ev=isEventDay(d);if(d.getDay()===2||d.getDay()===4||ev)break;d.setDate(d.getDate()+1)}
      var when=i===0?'stasera':(i===1?'domani':DAYS[d.getDay()]);
      lt.textContent=(ev?'Musica dal vivo '+when:'Apre '+when)+' alle '+ORARIO;
    }
    var ne=nextEvent(), label=longDate(ne);
    $('#evDate').textContent=label+', dalle '+ORARIO;
    $('#doveEv').textContent='Il prossimo: '+label.toLowerCase();
    var po=mem.poster&&mem.poster.date===iso(ne)?mem.poster:null, box=$('#poster');
    var key=po?po.img:'vuoto:'+label;
    if(box.getAttribute('data-k')!==key){
      box.setAttribute('data-k',key);
      box.innerHTML = po
        ? '<img src="'+po.img+'" alt="Locandina dell\'evento di '+esc(label.toLowerCase())+'">'
        : '<div class="poster-empty"><small>'+esc(label)+'</small><strong>Stiamo preparando il prossimo evento</strong><p>La locandina arriva a breve. La pubblichiamo anche sul canale WhatsApp.</p></div>';
    }
    if(!wDate.options.length){
      wDate.innerHTML=upcomingNights(10).map(function(n){return '<option value="'+iso(n)+'">'+longDate(n)+'</option>'}).join('');
    }
    syncWa();
  }

  /* ---------- ingresso: foto del palco che scorre con la pagina ---------- */
  var intro=$('#ingresso'), photo=$('#introPhoto');
  var ch1=$('#ch1'), ch2=$('#ch2'), ch3=$('#ch3'), cue=$('#cue'), chLogo=$('#chLogo'), mark=$('.mark');
  function win(p,a,b,c,d){if(p<=a||p>=d)return 0;if(p<b)return (p-a)/(b-a);if(p<=c)return 1;return (d-p)/(d-c)}
  function show(el,o,center){el.style.opacity=o;el.style.transform=(center?'translateX(-50%) ':'')+'translateY('+((1-o)*18)+'px)';el.style.pointerEvents=o>.5?'auto':'none';el.setAttribute('aria-hidden',o<.05?'true':'false')}
  function drawIntro(){
    var r=intro.getBoundingClientRect(), span=intro.offsetHeight-window.innerHeight;
    if(!intro.offsetHeight){mark.style.opacity='';return}
    var p=reduce?1:clamp(-r.top/span,0,1);
    if(!reduce)photo.style.transform='scale('+(1.04+p*.12)+') translateY('+(-p*2)+'%)';
    /* si parte dal logo al centro: poi si dissolve e il resto entra, un pezzo alla volta */
    var lo=reduce?0:clamp(1-(p-.04)/.16,0,1);
    chLogo.style.opacity=String(lo);
    chLogo.style.transform='scale('+(1+(1-lo)*.35)+')';
    mark.style.opacity=String(reduce?1:clamp((p-.12)/.14,0,1));
    show(ch1,win(p,.14,.26,.42,.52)); show(ch2,win(p,.5,.6,.72,.82)); show(ch3,win(p,.86,.94,2,3),true);
    cue.style.opacity=String(clamp(1-p*14,0,1));
  }

  /* ---------- pannelli: entrano da destra, uno dopo l'altro ---------- */
  var rail=$('#rail'), pans=[].slice.call(document.querySelectorAll('#track .pan'));
  var wide=window.matchMedia('(min-width:900px)');
  function drawRail(){
    if(!wide.matches||reduce){pans.forEach(function(p){p.style.transform=''});return}
    var r=rail.getBoundingClientRect(), span=rail.offsetHeight-window.innerHeight;
    var p=clamp(-r.top/span,0,1), vw=window.innerWidth;
    pans.forEach(function(el,i){
      var q=clamp((p*1.25-i*.14)/.5,0,1), t=1-Math.pow(1-q,3);
      el.style.transform='translateX('+((1-t)*vw*(1+i*.08))+'px)';
    });
  }

  /* ---------- torna su ---------- */
  var toTop=$('#toTop');
  function drawTop(){toTop.classList.toggle('on',window.scrollY>window.innerHeight*1.2)}
  toTop.addEventListener('click',function(){window.scrollTo({top:0,behavior:reduce?'auto':'smooth'});$('.mark').focus()});

  var ticking=false;
  function onScroll(){ if(ticking)return; ticking=true; requestAnimationFrame(function(){drawIntro();drawRail();drawTop();ticking=false}) }
  function layout(){ drawIntro(); drawRail(); drawTop(); }
  window.addEventListener('scroll',onScroll,{passive:true});
  window.addEventListener('resize',layout);

  /* ---------- galleria: foto a tutto schermo ---------- */
  var lb=$('#lb'), lbImg=$('#lbImg'), lbCap=$('#lbCap'), lastBtn=null, lbList=[], lbI=0;
  function fullOf(b){return b.getAttribute('data-full')||b.querySelector('img').src}
  function showLb(){var b=lbList[lbI];lbImg.src=fullOf(b);lbImg.alt=b.querySelector('img').alt;lbCap.textContent=(lbI+1)+' / '+lbList.length;$('#lbPrev').hidden=$('#lbNext').hidden=lbList.length<2}
  function openLb(card,list,i){lastBtn=card.closest('.cf-frame');lbList=list;lbI=i;showLb();lb.classList.add('on');$('#lbX').focus()}
  function stepLb(d){lbI=(lbI+d+lbList.length)%lbList.length;showLb()}
  function closeLb(){lb.classList.remove('on');lbImg.removeAttribute('src');if(lastBtn)lastBtn.focus({preventScroll:true})}
  $('#lbX').addEventListener('click',closeLb);
  $('#lbPrev').addEventListener('click',function(){stepLb(-1)});
  $('#lbNext').addEventListener('click',function(){stepLb(1)});
  lb.addEventListener('click',function(e){if(e.target===lb)closeLb()});
  var tx=null;
  lb.addEventListener('touchstart',function(e){tx=e.touches[0].clientX},{passive:true});
  lb.addEventListener('touchend',function(e){if(tx===null)return;var dx=e.changedTouches[0].clientX-tx;tx=null;if(Math.abs(dx)>50)stepLb(dx<0?1:-1)},{passive:true});
  document.addEventListener('keydown',function(e){if(!lb.classList.contains('on'))return;if(e.key==='Escape'){e.preventDefault();closeLb()}else if(e.key==='ArrowRight')stepLb(1);else if(e.key==='ArrowLeft')stepLb(-1)});

  /* ---------- coverflow: le foto delle sale ---------- */
  (function(){
    var reduceCf=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var ROT=44, DEPTH=.6, FALL=.56, FADE=.1, GAP=.05;
    [].forEach.call(document.querySelectorAll('.cf'),function(root){
      var frame=root.querySelector('.cf-frame'), cards=[].slice.call(root.querySelectorAll('.cf-card')), count=cards.length, cap=root.querySelector('.cf-cap');
      var pos=0, target=0, width=0, raf=null, drag=null, selected=-1;
      function idxAt(v){return ((Math.round(v)%count)+count)%count}
      function setSel(i){if(i===selected)return;selected=i;cap.textContent=('0'+(i+1)).slice(-2)+' / '+('0'+count).slice(-2)}
      function paint(){
        if(!width)return;
        var pitch=width*(1+GAP);
        cards.forEach(function(c,i){
          var off=i-pos; off=((off%count)+count)%count; if(off>count/2)off-=count;
          var d=Math.abs(off), ramp=Math.pow(d,FALL), tilt=Math.min(ROT*ramp,82)*Math.sign(off);
          c.style.transform='translateX(calc(-50% + '+(off*pitch)+'px)) translateZ('+(-DEPTH*width*ramp)+'px) rotateY('+(-tilt)+'deg)';
          var edge=Math.min(1,Math.max(0,count/2-d));
          c.style.opacity=String(Math.max(0,1-FADE*d)*edge);
          c.style.zIndex=String(100-Math.round(d));
        });
      }
      function settle(t){
        if(raf!==null)cancelAnimationFrame(raf);
        target=t; setSel(idxAt(t));
        if(reduceCf){pos=t;paint();raf=null;return}
        (function step(){
          var rem=target-pos;
          if(Math.abs(rem)<.0004){pos=target;paint();raf=null;return}
          pos+=rem*.16;paint();raf=requestAnimationFrame(step);
        })();
      }
      function goTo(i){settle(i+Math.round((target-i)/count)*count)}
      function nudge(by){settle(Math.round(target)+by)}
      function openAt(i){openLb(cards[i],cards,i)}
      frame.addEventListener('pointerdown',function(e){
        if(raf!==null){cancelAnimationFrame(raf);raf=null}
        try{frame.setPointerCapture(e.pointerId)}catch(_){}
        target=pos;
        drag={id:e.pointerId,x:e.clientX,pos:pos,v:0,t:performance.now(),moved:0};
      });
      frame.addEventListener('pointermove',function(e){
        if(!drag||drag.id!==e.pointerId)return;
        var pitch=width*(1+GAP); if(!pitch)return;
        var now=performance.now(), prev=pos;
        drag.moved=Math.max(drag.moved,Math.abs(e.clientX-drag.x));
        pos=drag.pos-(e.clientX-drag.x)/pitch;
        drag.v=((pos-prev)/Math.max(now-drag.t,1))*1000; drag.t=now;
        setSel(idxAt(pos)); paint();
      });
      function end(e){
        if(!drag||drag.id!==e.pointerId)return;
        var d=drag; drag=null;
        if(d.moved<6&&e.type==='pointerup'){
          /* un tocco, non un trascinamento: la foto al centro si ingrandisce, le altre arrivano al centro.
             La foto toccata si trova dalle coordinate (la piu' vicina al centro che copre il punto). */
          var hit=-1, best=-1;
          cards.forEach(function(c,i){var r=c.getBoundingClientRect();if(e.clientX>=r.left&&e.clientX<=r.right&&e.clientY>=r.top&&e.clientY<=r.bottom){var z=+c.style.zIndex||0;if(z>best){best=z;hit=i}}});
          if(hit<0){settle(Math.round(pos));return}
          if(hit===idxAt(pos)){settle(Math.round(pos));openAt(hit)}else goTo(hit);
          return;
        }
        var carried=Math.max(-2,Math.min(2,d.v*.18));
        settle(Math.round(pos+carried));
      }
      frame.addEventListener('pointerup',end); frame.addEventListener('pointercancel',end);
      frame.addEventListener('keydown',function(e){
        if(e.key==='ArrowLeft'){e.preventDefault();nudge(-1)}
        else if(e.key==='ArrowRight'){e.preventDefault();nudge(1)}
        else if(e.key==='Enter'||e.key===' '){e.preventDefault();openAt(idxAt(pos))}
      });
      root.querySelector('.cf-prev').addEventListener('click',function(){nudge(-1)});
      root.querySelector('.cf-next').addEventListener('click',function(){nudge(1)});
      function measure(){width=cards[0].offsetWidth;paint()}
      measure(); setSel(0);
      if('ResizeObserver' in window)new ResizeObserver(measure).observe(frame);else window.addEventListener('resize',measure);
    });
  })();

  renderGuest(); layout(); loadPublic();
  window.addEventListener('load',layout);
  setInterval(function(){if(!document.hidden)loadPublic()},60000);

  /* luce che segue il puntatore (spotlight + metallo) */
  document.addEventListener('pointermove',function(e){
    var t=e.target.closest&&e.target.closest('.btn.metal,.card-note'); if(!t)return;
    var r=t.getBoundingClientRect(); t.style.setProperty('--mx',(e.clientX-r.left)+'px'); t.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();

/* mappa Google: caricata solo quando l'utente la chiede */
(function(){
  var b=document.getElementById('mapBtn'); if(!b)return;
  b.addEventListener('click',function(){
    var f=document.createElement('iframe');
    f.title="Mappa di Mòrk's Place, Via Crova 11, Nizza Monferrato";
    f.src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2511.5025256318536!2d8.354289775644723!3d44.77356197925414!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478785de8291ea4b%3A0x6f96f30d6d0084f5!2sVia%20Crova%2C%2011%2C%2014049%20Nizza%20Monferrato%20AT!5e1!3m2!1sit!2sit!4v1794846564690!5m2!1sit!2sit'; f.loading='lazy'; f.allowFullscreen=true; f.referrerPolicy='strict-origin-when-cross-origin';
    var box=document.getElementById('map'); box.innerHTML=''; box.appendChild(f);
  });
})();
